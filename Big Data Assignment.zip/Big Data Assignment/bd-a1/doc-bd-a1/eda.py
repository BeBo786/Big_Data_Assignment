import os
import pandas as pd

script_directory = os.path.dirname(os.path.abspath(__file__))
parent_directory = os.path.abspath(os.path.join(script_directory, ".."))
file_path = os.path.join(parent_directory, "res_dpre.csv")

try:
    dataset = pd.read_csv(file_path)
except FileNotFoundError:
    print("Error: File not found at the specified path.")
    exit(1)
except pd.errors.EmptyDataError:
    print("Error: The dataset file is empty.")
    exit(1)

mean_age = dataset['Age'].mean()
insight_1 = f"Mean Age: {mean_age}"

unique_pclass_count = dataset['Pclass'].nunique()
insight_2 = f"Number of Unique Pclass: {unique_pclass_count}"

most_frequent_embarked = dataset['Embarked'].mode().iloc[0]
insight_3 = f"Most Frequent Embarked Value: {most_frequent_embarked}"

output_directory = os.path.join(parent_directory, "insights")
os.makedirs(output_directory, exist_ok=True)

insight_files = ["eda-in-1.txt", "eda-in-2.txt", "eda-in-3.txt"]
insights = [insight_1, insight_2, insight_3]

for i, insight_text in enumerate(insights):
    insight_file_path = os.path.join(output_directory, insight_files[i])
    with open(insight_file_path, "w") as file:
        file.write(insight_text)

print("Exploratory data analysis completed. Insights saved to text files.")
