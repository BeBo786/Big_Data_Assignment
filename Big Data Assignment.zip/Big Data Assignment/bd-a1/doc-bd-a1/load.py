import os
import sys
import pandas as pd

script_directory = os.path.dirname(os.path.abspath(__file__))

parent_directory = os.path.abspath(os.path.join(script_directory, ".."))

file_path = os.path.join(parent_directory, "train_titanic.csv")

try:
    dataset = pd.read_csv(file_path)
except FileNotFoundError:
    print("Error: File not found at the specified path.")
    sys.exit(1)
except pd.errors.EmptyDataError:
    print("Error: The dataset file is empty.")
    sys.exit(1)
