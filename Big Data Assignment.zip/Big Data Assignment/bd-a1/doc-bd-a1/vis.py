import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

script_directory = os.path.dirname(os.path.abspath(__file__))
parent_directory = os.path.abspath(os.path.join(script_directory, ".."))
file_path = os.path.join(parent_directory, "res_dpre.csv")

try:
    dataset = pd.read_csv(file_path)
except FileNotFoundError:
    print("Error: File not found at the specified path.")
    exit(1)
except pd.errors.EmptyDataError:
    print("Error: The dataset file is empty.")
    exit(1)


plt.figure(figsize=(8, 6))
sns.histplot(dataset['Age'], bins=20, kde=True, color='skyblue')
plt.title("Distribution of Age")
plt.xlabel("Age")
plt.ylabel("Frequency")
plt.tight_layout()
plt.savefig(os.path.join(parent_directory, "age_distribution.png"))
plt.close()

plt.figure(figsize=(8, 6))
sns.countplot(x='Pclass', data=dataset, palette='pastel')
plt.title("Passenger Class Distribution")
plt.xlabel("Pclass")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig(os.path.join(parent_directory, "pclass_distribution.png"))
plt.close()

print("Visualizations completed. Images saved.")
