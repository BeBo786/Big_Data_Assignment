import os
import pandas as pd
from sklearn.cluster import KMeans

script_directory = os.path.dirname(os.path.abspath(__file__))
parent_directory = os.path.abspath(os.path.join(script_directory, ".."))
data_path = os.path.join(parent_directory, "res_dpre.csv")
data = pd.read_csv(data_path)

selected_columns = ['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']

kmeans = KMeans(n_clusters=3, random_state=42)
data['Cluster'] = kmeans.fit_predict(data[selected_columns])

cluster_counts = data['Cluster'].value_counts()

insights_directory = os.path.join(parent_directory, "insights")
os.makedirs(insights_directory, exist_ok=True)
cluster_counts_path = os.path.join(insights_directory, "k.txt")
cluster_counts.to_csv(cluster_counts_path, header=False)

print("K-means clustering completed. Cluster counts saved to k.txt.")
