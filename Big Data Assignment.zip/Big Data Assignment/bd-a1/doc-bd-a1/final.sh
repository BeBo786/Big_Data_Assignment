#!/bin/bash



echo "Loading Data..."
/usr/bin/python3 "load.py"
if [ $? -ne 0 ]; then
    echo "Error occurred during data loading. Exiting."
    exit 1
fi
echo "Data loaded successfully."

echo "Preprocessing Data..."
/usr/bin/python3 "dpre.py"
if [ $? -ne 0 ]; then
    echo "Error occurred during data preprocessing. Exiting."
    exit 1
fi
echo "Data preprocessing completed."

echo "Performing Exploratory Data Analysis..."
/usr/bin/python3 "eda.py"
if [ $? -ne 0 ]; then
    echo "Error occurred during exploratory data analysis. Exiting."
    exit 1
fi
echo "Exploratory Data Analysis completed."

echo "Creating Visualizations..."
/usr/bin/python3 "vis.py"
if [ $? -ne 0 ]; then
    echo "Error occurred during data visualization. Exiting."
    exit 1
fi
echo "Data visualization completed."

echo "Training Machine Learning Model..."
/usr/bin/python3 "model.py"
if [ $? -ne 0 ]; then
    echo "Error occurred during model training. Exiting."
    exit 1
fi
echo "Model training completed."

echo "All steps completed successfully."


#!/bin/bash

# Your existing code for data processing and model training...

# Copy specific output files from the container to the local machine's service-result directory
echo "Copying output files from the container to local machine..."
 cp bd-a1-container:/bd-a1/res_dpre.csv "C:\Users\SEIF ELDIN\OneDrive\Desktop\bd-a1\service-result"
 cp bd-a1-container:/bd-a1/insights/ "C:\Users\SEIF ELDIN\OneDrive\Desktop\bd-a1\service-result"
 cp bd-a1-container:/bd-a1/visualizations/ "C:\Users\SEIF ELDIN\OneDrive\Desktop\bd-a1\service-result"
 cp bd-a1-container:/bd-a1/k.txt "C:\Users\SEIF ELDIN\OneDrive\Desktop\bd-a1\service-result"
 cp bd-a1-container:/bd-a1/model.pkl "C:\Users\SEIF ELDIN\OneDrive\Desktop\bd-a1\service-result"
if [ $? -ne 0 ]; then
    echo "Error occurred during file copying. Exiting."
    exit 1
fi
echo "Output files copied to local machine successfully."


echo "Stopping the container..."
 stop bd-a1-container
echo "Container stopped successfully."


