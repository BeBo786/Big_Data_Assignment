import os
import sys
import pandas as pd
from sklearn.preprocessing import LabelEncoder

script_directory = os.path.dirname(os.path.abspath(__file__))
parent_directory = os.path.abspath(os.path.join(script_directory, ".."))
file_path = os.path.join(parent_directory, "train_titanic.csv")

try:
    dataset = pd.read_csv(file_path)
except FileNotFoundError:
    print("Error: File not found at the specified path.")
    sys.exit(1)
except pd.errors.EmptyDataError:
    print("Error: The dataset file is empty.")
    sys.exit(1)

dataset.dropna(subset=['Age', 'Embarked'], inplace=True)

label_encoders = {}
for column in ['Sex', 'Embarked']:
    label_encoders[column] = LabelEncoder()
    dataset[column] = label_encoders[column].fit_transform(dataset[column])

columns_to_drop = ['Name', 'Ticket', 'Cabin', 'PassengerId']
dataset.drop(columns=columns_to_drop, inplace=True)

dataset['Age'] = pd.cut(dataset['Age'], bins=5, labels=False)
dataset['Fare'] = pd.cut(dataset['Fare'], bins=5, labels=False)

output_file_path = os.path.join(parent_directory, "res_dpre.csv")
dataset.to_csv(output_file_path, index=False)

print("Data preprocessing completed. Result saved to res_dpre.csv.")
